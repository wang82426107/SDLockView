//
//  SDLockView.h
//  SDLockView
//
//  Created by songjc on 16/9/15.
//  Copyright © 2016年 Don9. All rights reserved.
//  联系作者QQ:676758285
//  作者简书地址:

#import <UIKit/UIKit.h>


@protocol SDLockViewDelegate <NSObject>

@optional
//三种界面(设置,修改,验证)操作成功之后调用的方法.
-(void)operationWithSucceed;

@end


typedef enum  {
    SetPassWordType,//设置密码类型界面
    UpdataPassWordType,//修改密码类型界面
    TestingPassWordType,//验证密码类型界面
} LockViewType;



@interface SDLockView : UIView


/**
@author Don9

类创建方式,frame推荐使用全屏,

@param lockViewType 界面的类型

@return 创建一个手势验证页面,大小为屏幕的大小
*/

+(instancetype)initWithLockViewType:(LockViewType)lockViewType;

/*******************基本用法***********************/


//界面的类型
@property(nonatomic,assign)LockViewType lockViewType;


@property(nonatomic,assign)id <SDLockViewDelegate>delegate;



/*******************拓展用法设置***********************/


//背景图片的名称;如果不进行设置,则是白色背景
@property(nonatomic,strong)NSString *backgroundImageName;

//九宫格的边界距离(左 、右 、下,没有上边界,默认的为80)
@property(nonatomic,assign)CGFloat borderDistance;

//九宫格的Y轴大小(上边界)
@property(nonatomic,assign)CGFloat distanceY;

//连接线的颜色(默认为蓝色)
@property(nonatomic,strong)UIColor *lineColor;

//连接线的宽度(默认为5)
@property(nonatomic,assign)CGFloat lineWidth;

//未选中图片名称
@property(nonatomic,strong)NSString *noSelecteImageName;

//选中图片名称
@property(nonatomic,strong)NSString *selecteImageName;

//选中与未选中的图片尺寸大小
@property(nonatomic,assign)CGSize imageSize;

//验证的时候允许出错的次数.默认的为5次.
@property(nonatomic,assign)int faultCount;

//验证出错之后,默认的用户再次等待时间为60秒
@property(nonatomic,assign)int waitTime;

/*******************文字信息设置***********************/

//字体的颜色,默认的为黑色
@property(nonatomic,strong)UIColor *wordColor;

//字体的大小,默认大小为17
@property(nonatomic,assign)NSInteger wordSize;

/*******************提示信息设置***********************/

//设置成功之后是否有弹窗提醒,默认为YES
@property(nonatomic,assign)BOOL isAlertView;


@end
