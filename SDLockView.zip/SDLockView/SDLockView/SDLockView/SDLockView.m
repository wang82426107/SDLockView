//
//  SDLockView.m
//  SDLockView
//
//  Created by songjc on 16/9/15.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import "SDLockView.h"
#import "UIImage+SizeUpdata.h"

#define KmainWidth  self.frame.size.width
#define KmainHeight  self.frame.size.height
#define KlockPassWord @"lockPassWord"

@interface SDLockView (){

    int gestureRecognizerCount;//手势的次数

    int countDown;//倒计时
}


//提示信息
@property(nonatomic,strong)NSString *promptMessage;

@property(nonatomic,strong)NSMutableArray *allButtons;//保存当前页面的所有按钮的数组

@property(nonatomic,strong)NSMutableArray *selectedButtons;//选中按钮的数组

@property(nonatomic,strong)NSMutableArray *nowButtonIndex;//当前的选中按钮下标

@property(nonatomic,strong)NSMutableArray *updataPasswordArray;//修改手势密码的第一次数组

@property(nonatomic,strong)NSTimer *timer;//定时器

@end

@implementation SDLockView


-(instancetype)initWithFrame:(CGRect)frame{

    if (self = [super initWithFrame:frame]) {

        [self loadingAllDefaultSettings];
        
        [self loadingAllButton];
    }
    
    return self;

}

-(instancetype)initWithLockViewType:(LockViewType)lockViewType{
    
    
    if (self  = [super initWithFrame:[UIScreen mainScreen].bounds]) {
        
        self.lockViewType = lockViewType;

        [self loadingAllDefaultSettings];
        
        [self loadingAllButton];
        

    }

    return self;

}


+(instancetype)initWithLockViewType:(LockViewType)lockViewType{

    SDLockView *lockView = [[SDLockView alloc]initWithLockViewType:lockViewType];
    
    return lockView;

}

#pragma mark ---- 初始化中默认所有设置 ---
-(void)loadingAllDefaultSettings{

    self.backgroundColor = [UIColor whiteColor];

    self.borderDistance = 80;
    
    self.distanceY = 300;
    
    self.lineColor = [UIColor blueColor];
    
    self.lineWidth = 5;
    
    self.imageSize = CGSizeMake(50, 50);
    
    self.selecteImageName = @"选中.png";
    
    self.noSelecteImageName = @"未选中.png";
    
    self.faultCount = 5;
    
    self.waitTime = 60;
    
    self.isAlertView = YES;
    
    countDown = self.waitTime;
}


#pragma mark --- 加载所有的按钮 ---
-(void)loadingAllButton{
    
    self.allButtons = [NSMutableArray arrayWithCapacity:9];
    
    for (int i = 0; i<3; i++) {
        
        for (int j = 0; j<3; j++) {
            
            UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
            
            button.userInteractionEnabled = NO;
            
            [button setImage:[UIImage reSizeImage:[UIImage imageNamed:self.noSelecteImageName] toSize:self.imageSize] forState:UIControlStateNormal];
            
            [button setImage:[UIImage reSizeImage:[UIImage imageNamed:self.selecteImageName] toSize:self.imageSize] forState:UIControlStateSelected];
            
            CGFloat altogetherWidth = KmainWidth-self.borderDistance*2;

            button.frame = CGRectMake(self.borderDistance + (altogetherWidth/2-self.imageSize.width/2)*j, self.distanceY +(altogetherWidth/2-self.imageSize.height/2)*i, self.imageSize.width, self.imageSize.height);
            
            [self.allButtons addObject:button];
            
            [self addSubview:button];
            
        }
        
    }
    
}




#pragma mark --- 判断某一个点是否在在某一个按钮之上,如果存在,那么就返回当前按钮;否则返回nil. ---
-(UIButton *)isSucceedExistButtonWithPosition:(CGPoint)position{
    
    for (UIButton *button in self.allButtons) {
        
        if (CGRectContainsPoint(button.frame, position)) {
            

            
            return button;
            
            
        }
        
    }
    
    return nil;
    
    
    
}

-(NSMutableArray *)selectedButtons{

    if (!_selectedButtons) {
        
        _selectedButtons = [NSMutableArray arrayWithCapacity:9];
    }

    return _selectedButtons;
}
-(NSMutableArray *)nowButtonIndex{

    if (!_nowButtonIndex) {
        
        _nowButtonIndex = [NSMutableArray arrayWithCapacity:9];
    }
    
    return _nowButtonIndex;


}

#pragma mark ---- 绘制的整过过程 ----

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    UITouch *touch = [touches anyObject];
    
    CGPoint position = [touch locationInView:self];
    
    UIButton *button = [self isSucceedExistButtonWithPosition:position];
    
    if (button) {
        
        button.selected = YES;
        
        [self.selectedButtons removeAllObjects];
        
        [self.selectedButtons addObject:button];
        
    }
}

-(void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    UITouch *touch = [touches anyObject];

    CGPoint position = [touch locationInView:self];
    
    UIButton *button = [self isSucceedExistButtonWithPosition:position];
    
    if (button) {
        
        button.selected = YES;
        
        //判读是否存在,如果存在,则不存储.
        if (![self isExistWithButton:button]) {
            
            [self.selectedButtons addObject:button];

        }
        
    }
    
    [self setNeedsDisplay];
}



-(void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    
    //根据selectedButtons这个数组生成nowButtonIndex
    [self produceNowButtonIndexWithSelectedButtons];
    
    switch (_lockViewType) {
        case SetPassWordType:{
            
            //设置手势密码
            [self setPassWord];
            
        }
            break;
            
        case UpdataPassWordType:{
            
            //修改手势密码
            [self updataPassWord];

        }
            break;
            
        case TestingPassWordType:{
            
            //验证密码
            [self testingPassWord];
            
        }
            break;
            
    }

 
    //操作次数+1
    gestureRecognizerCount ++;

    //所有的按钮设置为不活跃状态
    for (UIButton *button in self.allButtons) {
        
        button.selected = NO;
        
    }
    
    //selectedButtons删除所有的选定按钮
    [self.selectedButtons removeAllObjects];
    
    //重新绘制
    [self setNeedsDisplay];
    
    
}


//查看selectedButtons是否存在某一个按钮

-(BOOL)isExistWithButton:(UIButton *)button{
    
    BOOL isExist = NO;
    
    for (UIButton *obj in self.selectedButtons) {
        
        if ([obj isEqual:button]) {
            
            isExist = YES;
            
        }
        
    }
    
    return isExist;
}

//根据selectedButtons这个数组生成nowButtonIndex

-(void)produceNowButtonIndexWithSelectedButtons{
    
    //如果nowButtonIndex数组中存在元素
    if (self.nowButtonIndex.count != 0) {
        
        [self.nowButtonIndex removeAllObjects];
    }
    
    
    for (UIButton *obj in self.selectedButtons) {
        
        //对这一次的手势操作的下标进行记录
        
        for (int i = 0; i<self.allButtons.count; i++) {
            
            UIButton *button = self.allButtons[i];
            
            if ([obj isEqual:button]) {
                
                [self.nowButtonIndex addObject:[NSNumber numberWithInt:(i+1)]];
                
            }
            
        }
        
    }
    
    
}

#pragma mark ---- 设置手势密码 -----

-(void)setPassWord{

    if (gestureRecognizerCount == 1) {
        
        NSArray *lockArray = [NSArray arrayWithArray:self.nowButtonIndex];
        
        
        [[NSUserDefaults standardUserDefaults] setObject:lockArray forKey:KlockPassWord];
        
        self.promptMessage = @"请再次绘制手势密码";
    }
    
    
    if (gestureRecognizerCount == 2) {
        
        NSArray *lockArray = [[NSUserDefaults standardUserDefaults] valueForKey:KlockPassWord];
        
        if ([self isEqualtoFirstArray:lockArray secondArray:self.nowButtonIndex]) {
            
            if (self.isAlertView) {
                
                tipWithMessage(@"设置密码成功!");

            }
            
            //调起代理方法
            if (self.delegate != nil && [self.delegate respondsToSelector:@selector(operationWithSucceed)]) {
                
                [self.delegate operationWithSucceed];
            }
            
        }else{
            
            //如果设置的不正确,那么就重置所有的设置.
            [[NSUserDefaults standardUserDefaults] removeObjectForKey:KlockPassWord];
            
            [self.nowButtonIndex removeAllObjects];
            
            tipWithMessage(@"两次设置的密码不一致!");
            
            self.promptMessage = @"请绘制手势密码";
            
            gestureRecognizerCount = 0;
            
        }
        
        
    }


}


#pragma mark ---- 修改手势密码 ----

-(void)updataPassWord{

    if (gestureRecognizerCount == 1) {
        
        NSArray *lockArray = [[NSUserDefaults standardUserDefaults] valueForKey:KlockPassWord];
        
        self.promptMessage = @"请绘制新手势密码";

        
        //验证失败
        if (![self isEqualtoFirstArray:lockArray secondArray:self.nowButtonIndex]) {
            tipWithMessage(@"原手势密码不正确!");
            
            self.promptMessage = @"请绘制原手势密码";
            
            gestureRecognizerCount = 0;
        }
        
    }
    
    if (gestureRecognizerCount == 2) {
        
        self.updataPasswordArray = [NSMutableArray arrayWithArray:self.nowButtonIndex];
        
        self.promptMessage = @"请再次绘制手势密码";
    
    }
    
    if (gestureRecognizerCount == 3) {
        
        if ([self isEqualtoFirstArray:self.updataPasswordArray secondArray:self.nowButtonIndex]) {
            
            if (self.isAlertView) {
                tipWithMessage(@"修改密码成功!");

            }
            
            if (self.delegate != nil && [self.delegate respondsToSelector:@selector(operationWithSucceed)]) {
                
                [self.delegate operationWithSucceed];
            }
            
            //存储
            [[NSUserDefaults standardUserDefaults] setObject:[NSArray arrayWithArray:self.nowButtonIndex] forKey:KlockPassWord];
        }else{
            
            //如果设置的不正确,那么就重置所有的设置.
            [self.updataPasswordArray  removeAllObjects];
            
            [self.nowButtonIndex removeAllObjects];
            
            tipWithMessage(@"两次手势密码不一致!");
            
            self.promptMessage = @"请绘制新手势密码";
            
            gestureRecognizerCount = 1;
            
        }
    
    }


}

#pragma mark --- 验证手势密码 ---

-(void)testingPassWord{

    if (gestureRecognizerCount <= self.faultCount) {
        
        NSArray *lockArray = [[NSUserDefaults standardUserDefaults] valueForKey:KlockPassWord];
        
        //验证成功
        if ([self isEqualtoFirstArray:lockArray secondArray:self.nowButtonIndex]) {
            
            if (self.isAlertView) {
                tipWithMessage(@"验证成功!");

            }
            
            if (self.delegate != nil && [self.delegate respondsToSelector:@selector(operationWithSucceed)]) {
                
                [self.delegate operationWithSucceed];
            }
            
        }else{
            
            if (self.faultCount-gestureRecognizerCount >0) {
                
                self.promptMessage = [NSString stringWithFormat:@"密码错误,还有%d次机会",self.faultCount-gestureRecognizerCount];
                
            }

        }
        
    }
    
    
    if (self.faultCount-gestureRecognizerCount ==0){
    
        //如果超过5次,那么就启动定时器
    
        [self.timer setFireDate:[NSDate distantPast]];
    
    
    }
    

}


-(NSTimer *)timer{

    if (nil == _timer ) {
        _timer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(timeWith60s) userInfo:nil repeats:YES];
    }

    return _timer;

}



//定时器操作
-(void)timeWith60s{

    self.promptMessage = [NSString stringWithFormat:@"%d秒之后可以再次输入",countDown];
    
    self.userInteractionEnabled = NO;
    
    
    [self setNeedsDisplay];
    
    countDown --;
    
    if (countDown <= 0) {
        
        self.promptMessage = @"请绘制手势密码";
        
        [self.timer setFireDate:[NSDate distantFuture]];
        
        self.userInteractionEnabled = YES;
        
        countDown =self.waitTime;
        
        gestureRecognizerCount = 0;
    }

}


//释放定时器
-(void)dealloc{

    if (self.timer != nil) {
        [self.timer invalidate];
        self.timer = nil;
    }

}


#pragma mark --- 验证两个数组是否相等 ----
-(BOOL)isEqualtoFirstArray:(NSArray *)firstArray secondArray:(NSArray *)secondArray{

    BOOL result = YES;
    
    

    if (firstArray.count != secondArray.count) {
        return NO;
    }
    
    for (int i = 0; i< firstArray.count; i++) {
        
        if (![firstArray[i] isEqual:secondArray[i]]) {
            
            result = NO;
        }
        
        
    }


    return result;
}

#pragma mark --- 设置各种属性 ---
-(void)setLockViewType:(LockViewType)lockViewType{

    _lockViewType = lockViewType;
    
    switch (_lockViewType) {
        case SetPassWordType:{
        
            gestureRecognizerCount = 1;
            
            self.promptMessage = @"请绘制手势密码";
        
            [self setNeedsDisplay];

        
        }
            break;
            
        case UpdataPassWordType:{
            
            gestureRecognizerCount = 1;
            
            self.promptMessage = @"请绘制原手势密码";
            
            [self setNeedsDisplay];
            
            
        }
            break;
            
        case TestingPassWordType:{
            
            gestureRecognizerCount = 1;
            
            self.promptMessage = @"请绘制手势密码";
            
            [self setNeedsDisplay];
            
            
        }
            break;

    }



}

-(void)setBackgroundImageName:(NSString *)backgroundImageName{

    self.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:backgroundImageName]];
    
    [self setNeedsDisplay];


}


-(void)setDistanceY:(CGFloat)distanceY{

    _distanceY = distanceY;
    
    for(UIView *view in [self subviews]){

        [view removeFromSuperview];
    
    }
    
    [self loadingAllButton];




}


-(void)setBorderDistance:(CGFloat)borderDistance{

    _borderDistance = borderDistance;
    
    for(UIView *view in [self subviews]){
        
        [view removeFromSuperview];
        
    }
    
    [self loadingAllButton];

}

-(void)setSelecteImageName:(NSString *)selecteImageName{

    _selecteImageName = selecteImageName;
    
    for(UIView *view in [self subviews]){
        
        [view removeFromSuperview];
        
    }
    
    [self loadingAllButton];

}

-(void)setNoSelecteImageName:(NSString *)noSelecteImageName{
    
    _noSelecteImageName = noSelecteImageName;

    for(UIView *view in [self subviews]){
        
        [view removeFromSuperview];
        
    }
    
    [self loadingAllButton];

}

-(void)setImageSize:(CGSize)imageSize{
    _imageSize = imageSize;
    
    for(UIView *view in [self subviews]){
        
        [view removeFromSuperview];
        
    }
    
    [self loadingAllButton];
    
}

-(void)setWaitTime:(int)waitTime{

    _waitTime = waitTime;
    
    countDown = _waitTime;
    

}

-(void)setWordColor:(UIColor *)wordColor{

    _wordColor = wordColor;
    
    
    [self setNeedsDisplay];

}

-(void)setWordSize:(NSInteger )wordSize{

    _wordSize = wordSize;
    
    [self setNeedsDisplay];

}

#pragma mark --- 绘制贝塞尔曲线 ----

- (void)drawRect:(CGRect)rect{
    
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    
    paragraphStyle.alignment = NSTextAlignmentCenter;//（两端对齐的）文本对齐方式：（左，中，右，两端对齐，自然）
    
    [self.promptMessage drawInRect:CGRectMake(0, self.distanceY - 40, KmainWidth, 40) withAttributes:@{
                 NSKernAttributeName: @8,
                 NSFontAttributeName : [UIFont systemFontOfSize:(self.wordSize?self.wordSize:17)],
                 NSForegroundColorAttributeName :(self.wordColor?self.wordColor:[UIColor blackColor]),
                 NSParagraphStyleAttributeName:paragraphStyle,
                                                                                                       }];
    
    
    

    UIBezierPath *path = [UIBezierPath bezierPath];
    
    int i = 0;
    
    for (UIButton *button in self.selectedButtons) {
        
        if (i == 0) {
            
            [path moveToPoint:button.center];
        }else{
        
        
            [path addLineToPoint:button.center];
        
        
        }
        
        i++;
        
        
    }


    [self.lineColor set];
    
    [path setLineWidth:self.lineWidth];
    
    [path setLineJoinStyle:kCGLineJoinRound];
    
    [path stroke];

}


//提示弹窗
NS_INLINE void tipWithMessage(NSString *message){
    
    dispatch_async(dispatch_get_main_queue(), ^{
        
        UIAlertView *alerView = [[UIAlertView alloc] initWithTitle:@"提示" message:message delegate:nil cancelButtonTitle:nil otherButtonTitles:nil, nil];
        
        [alerView show];
        
        [alerView performSelector:@selector(dismissWithClickedButtonIndex:animated:) withObject:@[@0, @1] afterDelay:0.9];
        
    });
    
}
@end
