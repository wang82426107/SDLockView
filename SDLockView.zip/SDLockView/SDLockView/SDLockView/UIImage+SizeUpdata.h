//
//  UIImage+SizeUpdata.h
//  SDLockView
//
//  Created by songjc on 16/9/15.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (SizeUpdata)

//修改图片尺寸
+ (UIImage *)reSizeImage:(UIImage *)image toSize:(CGSize)reSize;

@end
