//
//  UIImage+SizeUpdata.m
//  SDLockView
//
//  Created by songjc on 16/9/15.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import "UIImage+SizeUpdata.h"

@implementation UIImage (SizeUpdata)

+ (UIImage *)reSizeImage:(UIImage *)image toSize:(CGSize)reSize{
    
    UIGraphicsBeginImageContext(CGSizeMake(reSize.width, reSize.height));
    
    [image drawInRect:CGRectMake(0, 0, reSize.width, reSize.height)];
    
    UIImage *reSizeImage = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
    return reSizeImage;
    
}

@end
