//
//  SDLockViewController.h
//  SDLockView
//
//  Created by songjc on 16/9/15.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SDLockView.h"


@interface SDLockViewController : UIViewController


@property(nonatomic,assign)LockViewType lockViewType;

@end
