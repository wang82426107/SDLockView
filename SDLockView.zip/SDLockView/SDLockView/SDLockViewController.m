//
//  SDLockViewController.m
//  SDLockView
//
//  Created by songjc on 16/9/15.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import "SDLockViewController.h"
#define KmainWidth  self.view.frame.size.width
#define KmainHeight  self.view.frame.size.height

@interface SDLockViewController ()<SDLockViewDelegate>


@end

@implementation SDLockViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    
    SDLockView *view = [SDLockView initWithLockViewType:self.lockViewType];
    
    view.waitTime = 10;
    
    view.backgroundImageName = @"夜空.jpeg";
//    view.lineColor = [UIColor blueColor];
//    
//    view.lineWidth = 5;
//    
//    view.lockViewType = TestingPassWordType;
    
    view.wordColor = [UIColor whiteColor];
    
    [self.view addSubview:view];
    view.delegate = self;

}

-(void)operationWithSucceed{


    NSLog(@"成功!");
    
    [self dismissViewControllerAnimated:YES completion:nil];


}

@end
