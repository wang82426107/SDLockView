//
//  ViewController.m
//  SDLockView
//
//  Created by songjc on 16/9/21.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import "ViewController.h"
#import "SDLockViewController.h"



@implementation ViewController



- (IBAction)setPassword:(id)sender {
    
    SDLockViewController *lockViewController =[[SDLockViewController alloc]init];
    
    lockViewController.lockViewType = SetPassWordType;
    
    [self presentViewController:lockViewController animated:YES completion:nil];
    
}


- (IBAction)updataPassword:(id)sender {
    SDLockViewController *lockViewController =[[SDLockViewController alloc]init];
    
    lockViewController.lockViewType = UpdataPassWordType;
    
    [self presentViewController:lockViewController animated:YES completion:nil];
}


- (IBAction)testingPassword:(id)sender {
    SDLockViewController *lockViewController =[[SDLockViewController alloc]init];
    
    lockViewController.lockViewType = TestingPassWordType;
    
    [self presentViewController:lockViewController animated:YES completion:nil];
    
    
}

@end
